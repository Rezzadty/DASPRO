#include <iostream>

using namespace std;

int main()
{
        cout << "Test Kasus 3" << endl;
        cout << "" << endl;

    int number1,number2;
        cout << "Input first Number : "; cin >> number1;
        cout << "Input Second Number : "; cin >> number2;
    if(number1>number2){
        cout << "Bilangan ke 1 Lebih besar dibandingkan bilangan ke 2"<< endl;
    }
    else {
        cout << "Bilangan ke 2 lebih besar dibandingkan bilangan ke 1"<< endl;
    }
    return 0;
}
