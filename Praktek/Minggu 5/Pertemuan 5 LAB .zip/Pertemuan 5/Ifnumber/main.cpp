#include <iostream>

using namespace std;

int main(){
    cout << "Test Kasus 1 " << endl;
    cout << "" << endl;
    int number;
    cout << "Put a number : " << endl; cin >> number;
    if (number>0){
        cout << number << " is positive " << endl;
    }
    else{
        cout << number << " is negative " << endl;
    }
    return 0;
}
