#include <iostream>

using namespace std;

int main()
{
    cout << "Test Kasus 2 " << endl;
    cout << "" <, endl;

    int Nilai;
    cout << " Input Your Number "; cin >> Nilai;
    int Hasil_Nilai;
    if (Nilai > 60){
        cout << " Selamat Anda Lulus " << endl;
    }
    else {
        cout  << " Mohon Maaf, anda tidak lulus " << endl;
    }
    return 0;
}
